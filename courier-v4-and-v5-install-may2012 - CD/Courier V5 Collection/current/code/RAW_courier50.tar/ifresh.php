<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: ifresh.php
Called by: javascript within inbox.html
Description/Notes: Refreshes list of current inbox
Update History:
06/02/12 DSK - Code tidy
03/01/12 MD  - Released
========================================================================================= */
require "./global/main.inc";
// DO NOT RESET expiration IN SESSIONS TABLE OR REFRESH WILL CAUSE TIMEOUT TO FAIL
if(!($USR && $LVL>=4) || !otpchk()):
    echo <<<EOT
    <div id="login">
        Your session has timed out. Click on the Reconnect button to log in again.
        <button type="button" class="btn" onclick="location.replace('index.html')">Reconnect</button>
    </div>
EOT;
else:
    $getsents = mysql_query("SELECT archive.*, uplds.expiry, upldinternal.downloaded, CONCAT(publisher.title,' ',publisher.forename,' ',publisher.surname) AS pubname
    FROM archive, upldinternal, uplds, recips AS publisher
    WHERE uplds.id=archive.id AND publisher.operator=archive.publisher AND upldinternal.upid=archive.id AND upldinternal.operator=archive.operatorto AND archive.operatorto='$USR' AND archive.authorised='1'
    ORDER BY archive.pid, archive.fname") or die("getting inbox ");
    $tdy    = date("Y-m-d");
    $rc     = "trow11";
    $srows  = "";
    while ($sent = mysql_fetch_array($getsents)):
        $rc         = $rc=="trow10" ? "trow11": "trow10";
        $fileid     = $sent['id'];
        $daysleft   = diffdays($tdy, $sent['expiry']);
        $sender     = $sent['fsource']=="RR" ? $sent['recipient']: $sent['pubname'];
        $senton     = tidydate($sent['pubdate']);
        $reply      = $sent['fsource']=="RR" ? "Yes": "";
        $rowclass   = $daysleft > 1 ? $rc : "alarm";
        $dncls      = $sent['downloaded']==0 ? "class=\"nodnld\"": "";
        $click      = "class=\"clkbl $rowclass\" onclick=\"location.replace('inbox2.html?fn=idisp&id=$fileid')\"";
        $srows     .= "<tr $click><td $dncls>$sender</td><td $dncls>$senton</td><td $dncls>${sent['fname']}</td><td $dncls>${sent['fdescr']}</td><td $dncls>${sent['fsize']}</td><td $dncls align=\"center\">$reply</td></tr>\n";
    endwhile;
    $INBOX =<<<EOT
    <h2>Files sent to you</h2>
    <div class="tblcnt">
        <table>
            <tr><th>Sent By</th><th>Date</th><th>File Name</th><th>Description</th><th>Size</th><th>Reply</th></tr>\n
            $srows
        </table>
    </div>
EOT;

    if ($LVL == 8):
        $getosents = mysql_query("SELECT DISTINCT archive.*, uplds.expiry, CONCAT(recips.title,' ',recips.forename,' ',recips.surname) AS toname
        FROM archive, upldinternal, uplds, recips
        WHERE uplds.id=archive.id AND recips.operator=archive.operatorto AND upldinternal.upid=archive.id AND upldinternal.operator=archive.operatorto AND archive.operatorto!='$USR' AND archive.fsource='RR'
        ORDER BY archive.pid, archive.fname") or die("getting replies ");
        $rc     = "trow11";
        $orows  = "";
        while ($osent = mysql_fetch_array($getosents)):
            $rc         = $rc=="trow10" ? "trow11": "trow10";
            $fileid     = $osent['id'];
            $senton     = tidydate($osent['pubdate']);
            $daysleft   = diffdays($tdy, $osent['expiry']);
            $sender     = $osent['recipient'];
            $reply      = $sent['fsource']=="RR" ? "Yes": "";
            $rowclass   = $daysleft > 1 ? $rc: "alarm";
            $click      = "class=\"clkbl $rowclass\" onclick=\"location.replace('inbox2.html?fn=odisp&id=$fileid')\"";
            $orows     .= "<tr $click><td>${osent['toname']}</td><td>$senton</td><td>$sender</td><td>${osent['fname']}</td><td>${osent['fdescr']}</td><td>${osent['fsize']}</td><td align=\"center\">$reply</td></tr>\n";
        endwhile;
        $INBOX .=<<<EOT
        <h2>Replies sent to others by recipients</h2>
        <div class="tblcnt">
            <table>
                <tr><th>Sent To</th><th>Date</th><th>Sent By</th><th>File Name</th><th>Description</th><th>Size</th></tr>\n
                $orows
            </table>
        </div>
EOT;
    endif;
    echo $INBOX ."<br />Inbox refreshed".date("H:i");
endif;
?>