<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: afresh.php
Called by: javascript within /authbox.html
Description/Notes:  Refreshes list of current inbox
Update History:
24/03/12 DSK - Minor refactor to fit with new styling
03/01/12 MD  - Released
========================================================================================= */
require "./global/main.inc";
// DO NOT RESET expiration IN SESSIONS TABLE OR REFRESH WILL CAUSE TIMEOUT TO FAIL
$getauths = mysql_query("SELECT recipient.id, recipient.expiry, recipient.email, CONCAT(recipient.title,' ',recipient.forename,' ',recipient.surname) AS recname, CONCAT(publisher.title,' ',publisher.forename,' ',publisher.surname) AS pubname, COUNT(upldpass.upid) AS numexts, COUNT(upldinternal.upid) AS numints
FROM recipassword AS recipient
LEFT JOIN upldinternal ON upldinternal.pid=recipient.id
LEFT JOIN upldpass ON upldpass.pid=recipient.id
LEFT JOIN recips AS publisher ON recipient.publisher=publisher.operator
WHERE recipient.authoriser='$USR' AND recipient.authorised='0' AND recipient.dunflag='1'
GROUP BY recipient.id");
if ($LVL == 8):
    $lglk = _LOGINFAILS_;
    $r = mysql_query("SELECT password.id , CONCAT(recips.title,' ',recips.forename,' ',recips.surname) AS fullname FROM password, recips WHERE recips.operator=password.id AND password.failcount>='$lglk'") ;
    $numlocks = mysql_num_rows($r);
    $r = mysql_query("SELECT recipassword.id , CONCAT(recipassword.title,' ',recipassword.forename,' ',recipassword.surname) AS fullname FROM recipassword WHERE recipassword.failcount>='$lglk'") ;
    $numlocks += mysql_num_rows($r);
    $getouths = mysql_query("SELECT recipient.id, CONCAT(recipient.title,' ',recipient.forename,' ',recipient.surname) AS recname, recipient.expiry, CONCAT(publisher.title,' ',publisher.forename,' ',publisher.surname) AS pubname, CONCAT(authoriser.title,' ',authoriser.forename,' ',authoriser.surname) AS authname, COUNT(upldpass.upid) AS numexts, COUNT(upldinternal.upid) AS numints
    FROM recipassword AS recipient
    LEFT JOIN upldinternal ON upldinternal.pid=recipient.id
    LEFT JOIN upldpass ON upldpass.pid=recipient.id
    LEFT JOIN recips AS publisher ON recipient.publisher=publisher.operator
    LEFT JOIN recips AS authoriser ON recipient.authoriser=authoriser.operator
    WHERE recipient.authoriser!='$USR' AND recipient.authorised='0' AND recipient.dunflag='1'
    GROUP BY recipient.id");
else:
    $numlocks = 0;
    $getouths = mysql_query("SELECT recipient.id, recipient.expiry, recipient.email, CONCAT(recipient.title,' ',recipient.forename,' ',recipient.surname) AS recname, CONCAT(authoriser.title,' ',authoriser.forename,' ',authoriser.surname) AS authname, COUNT(upldpass.upid) AS numexts, COUNT(upldinternal.upid) AS numints
    FROM recipassword AS recipient
    LEFT JOIN upldinternal ON upldinternal.pid=recipient.id
    LEFT JOIN upldpass ON upldpass.pid=recipient.id
    LEFT JOIN recips AS authoriser ON recipient.authoriser=authoriser.operator
    WHERE recipient.publisher='$USR' AND recipient.authorised='0' AND recipient.dunflag='1'
    GROUP BY recipient.id");
endif;
$LKPPL    = ($numlocks>1 ? "are " : "is ")."$numlocks".($numlocks>1 ? " people" : " person");
$DLCKOUT  = ($LVL == 8 && $numlocks) ? "<div id=\"lck\">There $LKPPL locked out of the system. <a href=\"maint/unlock.html\">View Details</a></div>" : "";
$tdy      = date("Y-m-d");

$arows = "";
$rc = "trow11";
while ($auth = mysql_fetch_array($getauths)):
    $rc = ($rc=="trow10"?"trow11":"trow10");
    $recipient = $auth['id'];
    $daysleft  = diffdays($tdy, $auth['expiry']);
    $numfiles  = $auth['numexts']+$auth['numints'];
    $rowclass  = $daysleft > 1 ? $rc : "alarm";
    $click     = "class=\"clkbl $rowclass\" onclick=\"location.replace('authbox2.html?fn=auth&id=$recipient')\"";
    $arows    .= "<tr $click><td>{$auth['id']}</td><td>${auth['pubname']}</td><td>${auth['recname']}</td><td>${auth['email']}</td><td align=\"center\">$numfiles</td><td align=\"center\">$daysleft</td></tr>\n";
endwhile;

$thhdr = $LVL==8 ? "Files needing authorisation by others" : "Your files awaiting authorisation";
$thpub = $LVL==8 ? "<th>Publisher</th>" : "";
$orows  = "";
$rc     = "trow11";
while ($outh = mysql_fetch_array($getouths)):
    $rc         = $rc=="trow10" ? "trow11": "trow10";
    $recipient  = $outh['id'];
    $daysleft   = diffdays($tdy, $outh['expiry']);
    $numfiles   = $outh['numexts']+$outh['numints'];
    $rowclass   = $daysleft > 1 ? $rc : "alarm";
    $publshr    = $LVL==8 ? "<td>${outh['pubname']}</td>" : "";
    $click      = "class=\"clkbl $rowclass\" onclick=\"location.replace('authbox2.html?fn=outh&id=$recipient')\"";
    $orows     .= "<tr $click><td>${outh['id']}</td>$publshr<td>${outh['recname']}</td><td align=\"center\">$numfiles</td><td align=\"center\">$daysleft</td><td>${outh['authname']}</td></td></tr>\n";
endwhile;
$refrshtm = date("H:i");

echo <<<EOT
$DLCKOUT
<h2>Files needing Your Authorisation</h2>
<div class="tblcnt">
    <table>
        <tr><th>ID</th><th>Publisher</th><th>Recipient</th><th>Email</th><th>Files</th><th>Expiry</th></tr>
        $arows
    </table>
</div>
<h2>$thhdr</h2>
<div class="tblcnt">
    <table>
        <tr><th>ID</th>$thpub<th>Recipient</th><th width="40">Files</th><th>Expiry</th><th>Authoriser</th></tr>
        $orows
    </table>
</div>
<br />Lists refreshed $refrshtm
EOT;
?>