<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: ofresh.php
Called by: javascript within /outbox.html
Description/Notes:  Refreshes list of current publications
Update History:
26/03/12 DSK - Minor refactor for styling
03/01/12 MD  - Released
========================================================================================= */
require "./global/main.inc";
// DO NOT RESET expiration IN SESSIONS TABLE OR REFRESH WILL CAUSE TIMEOUT TO FAIL
$PGID    = $LVL==8?"out2":"out1";
$HLPBTN  = gethlp($PGID, 0);

$getmine = mysql_query("SELECT recipassword.id, recipassword.email, CONCAT(recipassword.title,' ',recipassword.forename,' ',recipassword.surname) AS fullname, recipassword.authoriser, recipassword.authorised, recipassword.email, recipassword.expiry, CONCAT(authoriser.title,' ',authoriser.forename,' ',authoriser.surname) AS authname, COUNT(upldpass.upid) AS numexts, COUNT(upldinternal.upid) AS numints
FROM recipassword
LEFT JOIN upldinternal ON upldinternal.pid=recipassword.id
LEFT JOIN upldpass ON upldpass.pid=recipassword.id
LEFT JOIN password ON password.id=recipassword.authoriser
LEFT JOIN recips AS authoriser ON authoriser.operator=password.id
WHERE recipassword.publisher='$USR' AND recipassword.authorised='1' AND recipassword.dunflag='1'
GROUP BY recipassword.id") or die(mysql_error());
if ($LVL == 8):
    $lglk = _LOGINFAILS_;
    $r = mysql_query("SELECT password.id,CONCAT(recips.title,' ',recips.forename,' ',recips.surname) AS fullname FROM password, recips WHERE recips.operator=password.id AND password.failcount>='$lglk'");
    $numlocks = mysql_num_rows($r);
    $r = mysql_query("SELECT recipassword.id , CONCAT(recipassword.title,' ',recipassword.forename,' ',recipassword.surname) AS fullname FROM recipassword WHERE recipassword.failcount>='$lglk'");
    $numlocks += mysql_num_rows($r);
    $getyours = mysql_query("SELECT recipassword.id, recipassword.email, CONCAT(recipassword.title,' ',recipassword.forename,' ',recipassword.surname) AS fullname, recipassword.authoriser, recipassword.authorised, recipassword.email, recipassword.expiry, CONCAT(publisher.title,' ',publisher.forename,' ',publisher.surname) AS pubname, CONCAT(authoriser.title,' ',authoriser.forename,' ',authoriser.surname) AS authname, COUNT(upldpass.upid) AS numexts, COUNT(upldinternal.upid) AS numints
    FROM recipassword
    LEFT JOIN upldinternal ON upldinternal.pid=recipassword.id
    LEFT JOIN upldpass ON upldpass.pid=recipassword.id
    LEFT JOIN recips AS publisher ON recipassword.publisher=publisher.operator
    LEFT JOIN password ON password.id=recipassword.authoriser
    LEFT JOIN recips AS authoriser ON authoriser.operator=password.id
    WHERE recipassword.publisher!='$USR' AND recipassword.authorised='1' AND recipassword.dunflag='1'
    GROUP BY recipassword.id");
else:
    $numlocks = 0;
endif;
$LKPPL    = ($numlocks>1 ? "are " : "is ")."$numlocks".($numlocks>1 ? " people" : " person");
$DLCKOUT  = ($LVL == 8 && $numlocks) ? "<div id=\"lck\">There $LKPPL locked out of the system. <a href=\"maint/unlock.html\">View Details</a></div>" : "";
$tdy    = date("Y-m-d");
$rc     = "trow11";
$mrows  = "";
while ($m = mysql_fetch_array($getmine)):
    $rc = ($rc=="trow10"?"trow11":"trow10");
    $authby = ($m['authorised']==1 AND $m['authoriser']==0) ? "Publisher" : $m['authname'];
    $numfiles   = $m['numexts']+$m['numints'];
    $click  = "class=\"$rc clkbl\" onclick=\"location.replace('outbox2.html?fn=disp&id=${m['id']}')\"";
    $mrows .= "<tr $click><td>${m['id']}</td><td>${m['fullname']}</td><td>${m['email']}</td><td align=\"center\">$numfiles</td><td align=\"center\">".diffdays($tdy, $m['expiry'])."</td><td>$authby</td></tr>\n";
endwhile;
$YOURS = "";
if ($LVL == 8):
    $rc     = "trow11";
    $yrows  = "";
    while ($y = mysql_fetch_array($getyours)):
        $rc = ($rc=="trow10"?"trow11":"trow10");
        $authby = ($y['authorised']==1 AND $y['authoriser']==0) ? "Publisher" : $y['authname'];
        $numfiles   = $y['numexts']+$y['numints'];
        $click  = "class=\"$rc clkbl\" onclick=\"location.replace('outbox2.html?fn=disp&id={$y['id']}')\"";
        $yrows .= "<tr $click><td>{$y['id']}</td><td>{$y['pubname']}</td><td>{$y['fullname']}</td><td>{$y['email']}</td><td align=\"center\">$numfiles</td><td align=\"center\">".diffdays($tdy, $y['expiry'])."</td><td>$authby</td></tr>\n";
    endwhile;
    $YOURS = <<<EOT
    <h2>Files currently published by others</h2>
    <div class="tblcnt">
        <table>
            <tr><th>ID</th><th>Publisher</th><th>Recipient</th><th>Email</th><th>Files</th><th>Expiry</th><th>Authoriser</th></tr>
            $yrows
        </table>
    </div>
EOT;
endif;

echo <<<EOT
$DLCKOUT
$HLPBTN $NL
<h2>Files currently published by you</h2>
<div class="tblcnt">
    <table>
        <tr><th>ID</th><th>Recipient</th><th>Email</th><th>Files</th><th>Expiry</th><th>Authoriser</th></tr>
        $mrows
    </table>
</div>
$YOURS
EOT;
echo  "<br />Lists refreshed".date("H:i");
?>