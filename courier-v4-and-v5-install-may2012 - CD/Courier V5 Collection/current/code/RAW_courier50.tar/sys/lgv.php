#!/usr/local/bin/php -q
<?php
/*  ================================================================================
Application:   Courier v5.0
Filename:      /usr/local/bin/lgv.php
Called by:     Syscom daemon
Description:   Get selected log file make available to web server for download
    This file must be owned and executable by root
Update History:
03/02/2012  DSK - Released
=================================================================================== */

require "/usr/local/include/iseeu/localcfg.inc";

set_time_limit(300);
$CNX    = mysql_connect($hostname, $user, $password) or die();
mysql_select_db($wrDB, $CNX);
$fid    = $argv[1];
$targ   = $argv[2];
$r      = mysql_query("SELECT * FROM  logparms WHERE id='$fid'");
$row    = mysql_fetch_array($r);
$fn     = strpos($row['fn'],"..") !== false ? "messages": $row['fn'];
$src    = "/var/log/$fn";
$ftarg  = _BASEDIR_."tmp/$targ";

copy($src, $ftarg);

$cmd    = "chown nobody $ftarg";
exec($cmd, $res);
mysql_query("UPDATE logparms SET lastview=NOW() WHERE id='$fid'");
?>