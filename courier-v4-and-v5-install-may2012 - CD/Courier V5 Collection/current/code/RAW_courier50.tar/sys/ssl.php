#!/usr/local/bin/php -q
<?php
/*  ================================================================================
Application: Courier v5.0
Filename: /usr/local/bin/ssl.php
Called by:     Syscom daemon
Description:    CSR - Generate certificate signing request
                INS - Install new certificate
                RSW - Re-start apache to activate new cert
    C=GB, ST=Middlesex, L=Teddington, O=Applied Web Technology Ltd., OU=Web services, CN=intra.appweb.co.uk/emailAddress=webmaster@appweb.co.uk
Update History:
03/02/2012  DSK - Released

=================================================================================== */

require "/usr/local/include/iseeu/localcfg.inc";

set_time_limit(300);
$CNX    = mysql_connect($hostname, $user, $password) or die();
mysql_select_db($wrDB, $CNX);
$sub    = $argv[1];
$targ   = $argv[2];

function gencsr($targ) {
$C      = _COUNTRY_;
$ST     = _PROVINCE_;
$L      = _LOCALITY_;
$O      = _ORGNAME_;
$OU     = _ORGUNIT_;
$CN     = _DOMAIN_;
$EM     = _SITEMAIL_;
$wkdir  =  _BASEDIR_."tmp/";

$sslconf = <<<EOT
# OpenSSL configuration file.
[ req ]
default_bits            = 2048
default_md              = sha1
default_keyfile         = privkey.pem
distinguished_name      = req_distinguished_name
attributes              = req_attributes
#x509_extensions = v3_ca # The extentions to add to the self signed cert

[ req_distinguished_name ]
countryName                     = Country code
countryName_min                 = 2
countryName_max                 = 2
stateOrProvinceName             = State or Province Name
localityName                    = Locality Name
0.organizationName              = Organization Name
organizationalUnitName          = Organizational Unit Name
commonName                      = Common Name
commonName_max                  = 64
emailAddress                    = Email Address
emailAddress_max                = 64
countryName_default             = $C
stateOrProvinceName_default     = $ST
localityName_default            = $L
0.organizationName_default      = $O
organizationalUnitName_default  = $OU
commonName_default              = $CN
emailAddress_default            = $EM
[ req_attributes ]
challengePassword  =
EOT;

$fp = fopen( $wkdir."openssl.cnf", "w");
fwrite($fp, $sslconf);
fclose($fp);
$cmd = "openssl req -new -nodes -key /etc/httpd/ssl.key/${CN}.key -out /etc/httpd/ssl.csr/${CN}.csr -config openssl.cnf -batch";
chdir($wkdir);
exec($cmd, $res);
$src    = "/etc/httpd/ssl.csr/${CN}.csr";
$ftarg  = $wkdir.$targ;
copy($src, $ftarg);
chown($ftarg,'nobody');
unlink("openssl.cnf");
}

function install($targ) {
$wkdir  =  _BASEDIR_."tmp/";
$src    = $wkdir.$targ;
// might need to some unzippy stuff here
$dest   = "/etc/httpd/ssl.crt/"._DOMAIN_.".crt";
copy($src, $dest);
unlink($src);
}

function restart() {
$cmd = "/usr/sbin/apachectl restart";
exec($cmd, $res);
}

switch ($sub):
    case "REQ":     gencsr($targ);      break;
    case "CRT":     install($targ);     break;
    case "WRB":     restart();          break;
endswitch;
?>