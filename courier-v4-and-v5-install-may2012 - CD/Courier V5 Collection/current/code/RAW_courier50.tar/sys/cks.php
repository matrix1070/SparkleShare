#!/usr/local/bin/php -q
<?php
/*  ================================================================================
Application:   Courier v5.0
Filename:      /usr/local/bin/lgv.php
Called by:     Syscom daemon
Description:   Calculate sha256sum for given uploaded file and stores result in DB
Update History:
03/02/2012  DSK - Released

=================================================================================== */

require "/usr/local/include/iseeu/localcfg.inc";

set_time_limit(300);
$CNX    = mysql_connect($hostname, $user, $password) or die("<html><body>Cannot Access Database Server</body></html>");
mysql_select_db($wrDB, $CNX);
$fid    = $argv[1];
$arg    = _BASEDIR_.$fid;
$qtbl   = "uplds";

if ($argc > 2 ):
    $arg    = _BASEDIR_."prestaged/$fid";
    $qtbl   = "prestaged";
endif;

$cmd    = "/usr/bin/sha256sum $arg";
exec($cmd, $res);

$cksum  = explode(" ",$res[0]);
mysql_query("UPDATE $qtbl SET fchecksum='$cksum[0]' WHERE id='$fid'");
?>