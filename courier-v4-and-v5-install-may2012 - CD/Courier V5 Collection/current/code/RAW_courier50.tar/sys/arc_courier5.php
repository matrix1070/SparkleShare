#!/usr/local/bin/php -q
<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: arc_courier5.php
Called by: cron or command line
Description/Notes: Deletes expired files & logins. Put in /etc/cron.daily
               Must be executable by root only to ensure files are deleted.
Update History:
26/01/12 MD  - Rewritten & released
========================================================================================= */
require "/usr/local/include/iseeu/localcfg.inc";
set_time_limit(300);
$CNX    = mysql_pconnect($hostname, $user, $password) or die("Courier clean up failed - could not connect to db.");
mysql_select_db($wrDB, $CNX);

// Delete file links for expired recipient's transactions UNLESS they are still awaiting authorisation.
// Don't delete links to replies as they expire with the uploaded file, not the original transaction.
$r = mysql_query("SELECT id FROM recipassword WHERE authorised='1' AND expiry>'0000-00-00' AND expiry<CURDATE()");
while ($pub = mysql_fetch_array($r)):
    mysql_query("DELETE FROM upldpass WHERE pid='${pub['id']}'");
    mysql_query("DELETE FROM upldinternal WHERE pid='${pub['id']}' AND isreply='N'");
    mysql_query("DELETE FROM replylist WHERE pid='${pub['id']}'");
endwhile;
// Delete expired recipients
mysql_query("DELETE FROM recipassword WHERE authorised='1' AND expiry>'0000-00-00' AND expiry<NOW()");

// Delete file links for recipients who don't have finished flag set, wait for expiry in case someone is working now
// There should'nt be any unless final stage of publishing goes haywire
$r = mysql_query("SELECT id FROM recipassword WHERE dunflag='0' AND expiry>'0000-00-00' AND expiry<CURDATE()");
while ($pub = mysql_fetch_array($r)):
    mysql_query("DELETE FROM upldpass WHERE pid='${pub['id']}'");
    mysql_query("DELETE FROM upldinternal WHERE pid='${pub['id']}' AND isreply='N'");
    mysql_query("DELETE FROM replylist WHERE pid='${pub['id']}'");
endwhile;
// Delete recipients who don't have finished flag set
mysql_query("DELETE FROM recipassword WHERE dunflag='0' AND access='2' AND expiry>'0000-00-00' AND expiry<CURDATE()");

//Delete recipients with no file links
$r = mysql_query("SELECT recipassword.id, upldpass.pid AS extpid, upldinternal.pid as intpid
FROM recipassword
LEFT JOIN upldpass ON upldpass.pid=recipassword.id
LEFT JOIN upldinternal ON upldinternal.pid=recipassword.id
WHERE upldpass.pid IS NULL AND upldinternal.pid IS NULL") or die("Linkless recipient error ");
while ($rcp = mysql_fetch_array($r)):
    mysql_query("DELETE FROM recipassword WHERE id='${rcp['id']}' LIMIT 1");
    mysql_query("DELETE FROM replylist WHERE pid='${pub['id']}'");
endwhile;

// Delete files with file retention expired and no links or with links only for replies .Clean up any reply links
// The only links left should be for transactions still awaiting authorisation or for replies.
$r = mysql_query("SELECT uplds.id, uplds.expiry, upldpass.upid AS extupid, upldinternal.upid as extupid, upldinternal.isreply
FROM uplds
LEFT JOIN upldpass ON upldpass.upid=uplds.id
LEFT JOIN upldinternal ON upldinternal.upid=uplds.id
WHERE upldpass.upid IS NULL AND (upldinternal.upid IS NULL OR upldinternal.isreply='Y') AND uplds.expiry>'0000-00-00' AND uplds.expiry<NOW()");
while($upload = mysql_fetch_array($r)):
    $n = _BASEDIR_.$upload['id'];
    unlink($n);
    mysql_query("UPDATE archive SET action='Expired', actdate=NOW(), actor=1 WHERE id='${upload['id']}'");
    mysql_query("DELETE FROM upldinternal WHERE pid='${pub['id']}'");
    mysql_query("DELETE FROM uplds WHERE id='${upload['id']}' LIMIT 1");
endwhile;
?>