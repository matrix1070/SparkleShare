#!/usr/local/bin/php -q
<?php
/*  ================================================================================
Application:   Courier v5.0
Filename:      /usr/local/bin/mlq.php
Called by:     Syscom daemon
Description:   Execute privileged postfix commands
    This file must be owned and executable by root
Update History:
03/02/2012  DSK - Released
=================================================================================== */

require "/usr/local/include/iseeu/localcfg.inc";
set_time_limit(300);
$CNX    = mysql_connect($hostname, $user, $password) or die();
$sub    = "Q";
if($argc == 3):
    $sub    = $argv[1];
    $id     = $argv[2];
elseif($argc == 2):
    $sub    = $argv[1];
endif;

function getq() {
global $wrDB, $CNX; mysql_select_db($wrDB, $CNX);
$results        = array();
$current_object = null;
$qlen           = 0;
$pipe = popen("/usr/bin/mailq", 'r');
while($pipe):
    $line = fgets($pipe);
    if ($line === false) break;
    if (strncmp($line, '-', 1) === 0) continue;
    $line = trim($line);
    if (!$line):
        if ($current_object):
            $results[]      = $current_object;
            $current_object = null;
        endif;
    endif;
    $res = preg_match('/^([A-Z0-9]{1,20})\s+([1-9][0-9]*)\s+((Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+[A-Za-z]{3}\s+[0-9]{2}\s+[0-9]{2}\:[0-9]{2}\:[0-9]{2})\s+([^ ]+)\s*$/', $line, $matches);
    if ($res) : // Insert message ID and other data into the object.
        $qlen +=1;
        $current_object = array(
                'id' => $matches[1],
                'size' => intval($matches[2]),
                'date' => strftime($matches[3]),
                'sender' => $matches[5],
                'failed' => false,
                'recipients' => ''
        );
    else: // Parse error lines and recipients in lines following the message ID.
        if ($current_object):
            if ($line[0] === "("):
                $current_object['failed'] = trim($line);
            else:
                $current_object['recipients'] .= trim($line);
            endif;
        endif;
    endif;
endwhile;
pclose($pipe);
@mysql_query("TRUNCATE TABLE mailq");
if ($qlen):
    foreach($results as $msg){
        mysql_query("INSERT INTO mailq SET id='${msg['id']}', msize='${msg['size']}',sdate='${msg['date']}',sender='${msg['sender']}',status='${msg['failed']}',recipient='${msg['recipients']}'");
    }
endif;
}

function qflush($id){
$cmd    = "/usr/sbin/postqueue -i $id";
exec($cmd, $res);
}
function del($id){
$cmd    = "/usr/sbin/postsuper -d $id";
exec($cmd, $res);
}

switch ($sub):
    case "REL":    qflush($id); break;
    case "DEL":    del($id);    break;
    default:       getq();      break;
endswitch;
?>