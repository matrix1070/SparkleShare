<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: helptext.php
Called by: Ajax  for everything in / with help text
Description/Notes: Displays the help text for the page. Page ID is passed as the parameter
Update History:
28/03/12 DSK - Re written for ajax calls
05/02/12 MD  - First release
========================================================================================= */

require "./global/main.inc";
if(isset($_GET['pg']) && (($USR && otpchk() && $LVL>=4) || (substr($_GET['pg'], 0, 3)=="log"))):
    $pg  = chkstring($_GET['pg'],10);
    $get = mysql_query("SELECT * FROM helptext WHERE pgid='$pg'");
    if ($got = mysql_fetch_array($get)):
        $title = $got['pgtitle'];
        $help  = nl2br($got['pgbody']);
    else:
        $title = "There is no help available.";
        $help  = "";
    endif;

    echo <<<EOT
    <script type="text/javascript">document.getElementById('hlpBox').style.display='block';</script>
    <div class="help">
        <div id="helptitle">$title</div>
        <div id="helpbody">$help</div>
        <div class="btnbox"><button type="button" onclick="document.getElementById('hlpBox').style.display='none';">Close</button></div>
    </div>
EOT;
endif;
?>