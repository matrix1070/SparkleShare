<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: global/getlogo.php
Called by: All pages
Description/Notes: Display user logo in header if extant else display default
Update History:
06/02/12 DSK - First release
========================================================================================= */
require "./main.inc";
ob_start();

$dlogo  = $_SERVER['DOCUMENT_ROOT']."${APPBASE}img/logo-tl2.png";
$logo   = _BASEDIR_."usys/logoimg.png";
if(file_exists($logo)):
    $dlogo  = $logo;
endif;

if ($fp   = fopen($dlogo, 'rb')):
    $img = fread($fp,filesize($dlogo));
else:
    die("Unable to open $dlogo");
endif;
//header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
//header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
//header("$type");
//header("Content-Transfer-Encoding: binary");
header('Content-Type: image/png');
echo $img;
ob_end_flush();