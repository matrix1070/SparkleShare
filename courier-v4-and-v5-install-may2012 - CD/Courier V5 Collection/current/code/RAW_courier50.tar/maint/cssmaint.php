<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: cssmaint.php
Called by: All maintenance pages
Description/Notes: Main style sheet for maint
Update History:
06/04/12 DSK - First release
========================================================================================= */
require "../global/main.inc";
/* --------- Header / Banner #header, #banner -----------*/
$hdbg       = "#fff";
$hdfg       = "#0089d8";

/* --------- Main body #icont -----------*/
$contbg     = "#ffd";

/* --------- Sub-menu / toolbar #submenu, #toolbar-----------*/
$tbbg       = "#ffd";
$tbbgh      = "#ffd";
$tbfg       = "blue";
$tbfgh      = "darkblue";
$tbbdr      = "#000";

/* --------- Footer #footer -----------*/
$ftbg       = "#fff";
$ftfg       = "#000";

// get user defined style settings from style table

mysql_select_db($aDB, $CNX);
$r  =  mysql_query("SELECT * FROM csssettings WHERE 1"); //WHERE sheet='maint'
if($r):
    while($css = mysql_fetch_array($r)) {${$css['setting']} = $css['value'];}
endif;

header('Content-type: text/css');

echo <<<EOT
@import url("../global/reset.css");

/* Main styles for maint pages */
html {background:#efeccc;}
body {font-family:Arial,Helvetica,sans-serif;font-size:13px;background:#fff;width:1173px;margin:0px auto 0 !important;border:0px;}
img {vertical-align:middle;border:none;}

#hlpBox {position:absolute;top:68px;left:31px;height:auto;width:460px;background:#dfd;padding:0;text-align:left;border:2px outset #444;display:none;z-index:999}
#helpicon {position:absolute;top:12px;right:20px;;margin:}
#helptitle {font-size:125%;font-weight:bold;width:100%;margin:0;text-align:center;background:#666;color:#ddd;padding:4px 0;}
#helpbody {width:96%;margin:10px auto 0;}
.help {font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#000;}

button {color:#333;border:1px solid #333;padding:3px 10px;font-size:14px;font-weight:bold;white-space:nowrap; margin-right:1em;}

#header {display:block;width:100%;height:110px;margin:0;position:relative;background:$hdbg;}
#sitelogo {width:256px; float:left;}
#banner {float:left;font-size:24px;font-weight:bold;color:$hdfg;margin:25px;}

#owner {position:absolute;height:22px;overflow:hidden;width:220px;top:3px;right:10px;background:url(../img/cog.png) 200px 0px no-repeat;
        line-height:1.8;border-radius:8px;padding:5px 5px;}

#icont {background:$contbg;position:relative;padding-bottom:16px;}

/* Top menu */
#tabs {font-family:Tahoma,sans-serif;position:absolute;width:1173px;margin:0;top:76px;border-bottom:2px solid #000;}
#tabs ul {float:right;margin:0;list-style:none;position:relative;top:3px}
#tabs li {float:left;margin:0 2px;border-top:2px solid #000; border-left:2px solid #000;border-right:2px solid #000;border-radius:4px;background:#fff;}
#tabs a {display:block;padding:5px 15px 4px 6px;text-decoration:none;font-weight:700;font-size:14px;color:#333;}
#tabs a:hover {color:#aaa !important;}
#tabs a.activ:hover {color:#888 !important;}
#tabs .activ {color:#888;border-bottom:3px solid $contbg;background:$contbg;}

/* Toolbar menu */
#toolbar {display:block;min-height:20px;margin:0;font-family:Tahoma;position:relative;top:1px;}
#toolbar a {float:left;margin:0;padding:3px 8px;border:1px solid $tbbdr;text-decoration:none;color:$tbfg;font-weight:bold;background:$tbbg;}
#toolbar a:lst-child {border-right:none;}
#toolbar a:hover {color:$tbfgh;text-decoration:underline;cursor:pointer;background:$tbbgh;}

#footer {display:block;clear:both;width:100%;height:100px;margin:0;border-top:1px solid #000;overflow:hidden;background:$ftbg;}
#footer a {font-size:14px;text-decoration:none;font-weight:bold;color:$ftfg;}
#lftlnk {display:block;width:345px;float:left;margin:35px 10px 0 30px;text-align:left;}
#blogo {width:256px;float:right;}
#rtlnk {display:block;width:345px;float:left;margin:35px 10px 0 35px;text-align:right;}

.clkbl:hover {background:lightblue;cursor:pointer;}

.tblcnt {display:block;clear:both;padding:5px;margin:0 15px;}
.tblcnt table {border:3px solid #bbb;width:100%}
.tblcnt p {font-size:13px;font-weight:normal;margin:0;}
.tblcnt th {background:#bbb;text-align:left;padding:3px;}
.tblcnt th.reorder {text-decoration:underline; text-align:left;}
.tblcnt tr td {line-height:1.3 !important;padding:3px;}
.tblcnt tr.nodnld td {font-weight:bold !important;}


a {color:#0000FF;text-decoration:underline;padding-top:5px;font-weight:bold;}
a:hover {color:#000;}
a.menu {font-size:120%;font-weight:bold;text-align:center;line-height:150%;text-decoration:underline;}
.alarm {background:#fff060;}
.txt {font-size:80%;}
.btxt {font-size:80%;font-weight:bold;}
.pgtitle {font-size:180%;font-weight:bold;text-align:left;line-height:0.4;color:black;}
.pghd {font-size:120%;font-weight:bold;text-align:left;line-height:1.5;}
.arthd {font-size:12px;font-weight:bold;text-align:center;line-height:1.1;}
.colhd {font-size:100%;font-weight:bold;text-align:center;line-height:110%;}
.ermsg {font-size:120%;color:red;font-weight:bold;text-align:left;line-height:1.1;}
.gdmsg {font-size:120%;color:green;font-weight:bold;text-align:left;line-height:110%;}
.tblhd {display:block;font-size:150%;font-weight:bold;text-align:left;margin-bottom:2px}
.butt {width:180px;height:20px;background:#3fb5fc;color:#21296A;font-size:14px;font-weight:normal;margin:8px;border:2px outset #21296a;padding:2px 0 6px;}
.butt a {display:block;text-align:center;}
.butt:hover {color:#ccc;cursor:pointer;border:2px inset #21296a;}

.trow10 {background:#ccccff}
.trow11 {background:#eeeeff;}
.tdcent {text-align:center;}
.gc {background:silver;padding:3px 6px;font-weight:bold;font-size:110%;}

.fxl {background:#dae0d2;border:2px solid #000;width:100%;}
.fxlst table {}
.fxlst td {font-size:100%;padding:3px 5px;}
.fxlst td button {font-size:90%;background:transparent;cursor:pointer;}
.fxlst th {font-size:110%;font-weight:bold;text-align:left;background:#999;border-bottom:1px solid #000;padding:3px 5px;}
.fxlst tbody tr:hover {background:lightblue;cursor:auto;}
.fxlst tbody tr {height:2.2em;}
.fxlst a {color:#000;font-weight:bold;}
.fxlst a:hover {color:#777;}

#ufrm {display:block;background:#eed ;margin:10px auto;width:95%;padding:8px;border-radius:16px;border:1px solid #999;}
#ufrm p {clear:both;text-align:center;font-weight:bold;color:#000;font-size:14px}
#ufrm table {width:100%;}
#ufrm th {color:#fff;font-size:13px;font-weight:bold;text-align:center;padding:0;border-right:#bbb solid 1px;height:30px;}
#ufrm td {color:#000;font-size:13px;font-weight:normal;border-bottom:1px solid silver;border-right:#bbb solid 1px;line-height:2.0;}
#ufrm td:last-child, #ufrm th:last-child {border-right:none;}
#ufrm tr:last-child td {border-bottom:none;}
#ufrm .addsrch{clear:both;float:left;width:100%;margin:10px 0;text-align:center;}
#ufrm .addsrch form{display:inline}
#ufrm a {color:#335588;font-size:90%;font-weight:bold;text-decoration:none;}
#ufrm a.tblhd {color:#fff;text-decoration:underline;text-align:center;}
#ufrm td.lbl{font-size:120%;font-weight:bold;text-align:right;}
.mxlst table{}
.mxlst td {font-size:100%;padding:3px 5px;}
.mxlst th {font-size:110%;font-weight:bold;text-align:left;background:#999;border-bottom:1px solid #000;padding:3px 5px;}
#ufrm a.mxlst:hover{color:#000; text-decoration:underline;}

#pfrm {display:block;background:#eed ;margin:10px auto;width:95%;padding:8px 0;border-radius:16px;border:1px solid #999;}
#pfrm p{clear:both;text-align:center;font-weight:bold;color:#666;font-size:14px}
#pfrm table{width:100%;margin:0 auto;}
#pfrm td{color:#000;font-size:13px;font-weight:normal;line-height:3.0;}
#pfrm td.btnbar {text-align: center;}
#pfrm td.fname {width: 60%;}
#pfrm button{width:9em; margin:1em;}

#weight {width:60%;margin:0 auto;font-weight:bold;font-size:18px;text-align:center;color:#e78514;visibility:hidden;}
#weight img{margin:0 .5em 1.2em 1em;}

/* -----------------------------------  Print  Styles -------------------------------------- */
body.list{font-family:Arial,Helvetica,sans-serif; background: #fff; background-color:#fff;color:#000;width:100%;}
#prnfrm {background-color:#fff;font-size:80%;line-height:120%;margin-left:5%;padding-left:1em;width:90%;}
#prnrm table{width:100%;margin:auto;}
#prnfrm tr.file{background-color:#eef;}
#prnfrm td.file{border-top: 1px solid black;}
#prnfrm th {background-color:#21296A;color:#fff;font-size:120%;font-weight:bold;text-align:left;line-height:130%;padding:3px}
#prnfrm td{color:#000;font-size:100%;font-weight:normal;}

/* -----------------------------------  Form  Styles -------------------------------------- */
.help{text-align:left;margin:0 1em 2px 1em;}
.tbox{margin-right:1em;}
.btnbox{text-align:right;margin:10px 0}

.cfrm{clear:both;width:80%;margin:20px auto;background:#eee;border-radius:16px;border:1px solid #999;padding:10px}
.cfrm label{text-align:right;font-size:13px;font-weight:bold;display:block;float:left;margin-bottom:6px;width:15em;padding-right:1em;line-height:1.6;color:#666}
.cfrm input{width:18em}
.cfrm fieldset{background:#ddf}
.cfrm legend {font-weight:bold;font-size:110%;padding:0 6px;}

#upl{clear:both;width:80%;margin:20px auto;background:#eee;border-radius:16px;border:1px solid #999;padding:10px}
#upl label {text-align:right;font-size:13px;font-weight:bold;display:block;float:left;margin-bottom:6px;width:15em;padding-right:1em;line-height:1.6;color:#666}
#upl input{width:18em}

.sfrm {clear:both;width:80%;margin:20px auto;background:#eee;border-radius:16px;border:1px solid #999;padding:10px}
.sfrm label {text-align:right;font-size:13px;font-weight:bold;display:inline-block;margin-bottom:6px;width:20em;padding-right:1em;line-height:1.6;color:#666}
.sfrm input {width:18em}

#hfrm{clear:both;width:90%;margin:20px auto;background:#eee;border-radius:16px;border:1px solid #999;padding:10px}
#hfrm label {text-align:right;font-size:13px;font-weight:bold;display:block;float:left;margin-bottom:6px;width:10em;padding-right:1em;line-height:1.6;color:#666}
#hfrm input {width:40em}
#hfrm textarea {width:60em}
#txttools {width: 100%; text-align:center; margin:10px 30px;}

#txtfm{clear:both;width:80%;margin:20px auto;background:#eee;padding:8px 0;border-radius:16px;border:1px solid #999;padding:10px}
#txtfm p{font-weight:bold;margin:10px 0 0 20px;}
#txtfm label{width:8em;line-height:1.8;font-size:15px;font-weight:bold;color:#666}
#txtfm select#mailvar{margin:0 4px;}
#txtfm input,#txtfm textarea{display:block;width:580px;padding:10px;margin:15px auto;}
#newop {display:none;position:absolute;top:260px;left:280px;width:460px;margin:1em auto;padding:8px 0;border-radius:16px;border:1px solid #999; background:#ddd;text-align:center;}

/* ----------------------------------- Risk Assessment Form -------------------------------------- */
#urafrm {display:block;background:#eee ;margin:10px auto;width:95%;padding:8px 0;border-radius:16px;border:1px solid #999;}
#urafrm img{position:relative;top:10px;left:-6px;z-index:99;}
#urafrm p{clear:both;text-align:center;font-weight:bold;color:#666;font-size:14px}
#urafrm table{width:101%;margin:-3px 0 0 -4px;border-collapse:collapse;}
#urafrm th{color:#fff;font-size:13px;font-weight:bold;text-align:center;padding:0;border-right:#bbb solid 1px;height:35px;}
#urafrm td{color:#000;font-size:13px;font-weight:normal;border-bottom:1px solid silver;border-right:#bbb solid 1px;line-height:1.1;}
#urafrm td:last-child, #ufrm th:last-child {border-right:none;}
#urafrm tr:last-child td{border-bottom:none;}

.cbtns {text-align:center;margin:10px 0}
.ssl {clear:both;width:80%;margin:20px auto;background:#eee;padding:8px 0;border-radius:16px;border:1px solid #999;padding:10px}
.ssl a {display:block;margin:auto;width:180px;padding:6px;border: 1px outset #000;background:#ccc;color:#000 !important;text-align:center;}
.ssl textarea {display:block;clear:both;width:42em;margin:0 auto 20px;}
EOT;
?>