<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: maint/helptext.php
Called by: Ajax  for everything in maint with help text
Description/Notes: Displays the help text for the page. Page ID is passed as the parameter
Update History:
28/03/12 DSK - Re written for ajax calls
05/02/12 MD  - First release
========================================================================================= */
require "../global/main.inc";
if(isset($_GET['pg']) && $USR && otpchk() && $LVL==8):
    $pg    = chkstring($_GET['pg'],10);
    $r     = mysql_query("SELECT * FROM helptext WHERE pgid='$pg'");
    $title = "There is no help available.";
    $help  = "";
    if ($hlp = mysql_fetch_array($r)):
        $title = $hlp['pgtitle'];
        $help  = nl2br($hlp['pgbody']);
    endif;

    echo <<<EOT
    <script type="text/javascript">document.getElementById('hlpBox').style.display='block';</script>
    <div class="help">
        <div id="helptitle">$title</div>
        <div id="helpbody">$help</div>
        <div class="btnbox"><button type="button" onclick="document.getElementById('hlpBox').style.display='none';">Close</button></div>
    </div>
EOT;
endif;
?>