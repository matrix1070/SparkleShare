/*  ========================================================================================
Application: Courier v5.0
Filename: global/jsfuncs.js
Called by: various
Description/Notes: Javascript routines, mainly validation
Update History:
06/10/10 MD - Added password length check to pucheck & pu2check
08/08/10 MD - Added f4check to check per file ra forms
30/07/10 MD - Added riskchk() to validate ra forms & modified p4check to include checking ra form answers
30/07/10 MD - Added fondle() for handling instructions
08/04/10 DSK - Add fcnfm(FormId, Func, msg) - Variable function form confirm and submit
01/01/10 MD  - upload form checking modified to suit two stages
16/05/09 MD  - trim() & checkNumber() added and form checking modified to use them
14/07/08 MD  - Released
===================================================================================== */

// strip spaces from the beginning and end of a string
function trim(str) {
   return str.replace(/^\s+|\s+$/g,'');
}

//popup window routine takes 4 args - window name, url to load, width,height
function popwin(wname,url,w,h) {
    var sw = screen.width;
    var sh = screen.height;
    var left = (sw - w)/2;
    var top = (sh - h)/2;
    var siz = "width="+w+",height="+h+",top="+top+",left="+left+",screenX="+left+",screenY="+top
    siz += ",scrollbars,resizable";
    var wp=window.open(url, wname, siz);wp.focus();
}

function rusure(gourl,msg) {
    a = window.confirm(msg);
    if (a) {location.replace(gourl);}
}

function  fcnfm(formId, fnc, msg) {
    a = window.confirm(msg);
    if (a) {
        document.forms[formId].fn.value = fnc;
        document.forms[formId].submit();
        }
}

function mailchk(emailStr) {
    var checkTLD=1;
    var knownDomsPat=/^(com|net|org|edu|int|mil|gov|biz|aero|name|coop|info|pro|museum)$/;
    var emailPat=/^(.+)@(.+)$/;
    var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]"; //removed _ from this pattern
    var validChars="\[^\\s" + specialChars + "\]";
    var quotedUser="(\"[^\"]*\")";
    var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;
    var atom=validChars + '+';
    var word="(" + atom + "|" + quotedUser + ")";
    var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
    var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
    var matchArray=emailStr.match(emailPat);
    if (matchArray==null) {
        //alert("Email address seems incorrect (check @ and .'s)");
        return false;
    }
    var user=matchArray[1];
    var domain=matchArray[2];
    for (i=0; i<user.length; i++) {
        if (user.charCodeAt(i)>127) {
            //alert("The username contains invalid characters.");
            return false;
        }
    }
    for (i=0; i<domain.length; i++) {
        if (domain.charCodeAt(i)>127) {
            //alert("The domain name contains invalid characters.");
            return false;
        }
    }
    if (user.match(userPat)==null) {
        //alert("The username doesn't seem to be valid.");
        return false;
    }
    var IPArray=domain.match(ipDomainPat);
    if (IPArray!=null) {
        // this is an IP address
        for (var i=1;i<=4;i++) {
            if (IPArray[i]>255) {
                //alert("Destination IP address is invalid!");
                return false;
            }
        }
        return true;
    }
    var atomPat=new RegExp("^" + atom + "$");
    var domArr=domain.split(".");
    var len=domArr.length;
    for (i=0;i<len;i++) {
        if (domArr[i].search(atomPat)==-1) {
            //alert("The domain name does not seem to be valid.");
            return false;
        }
    }
    if (checkTLD && domArr[domArr.length-1].length!=2 && domArr[domArr.length-1].search(knownDomsPat)==-1) {
        //alert("The address must end in a well-known domain or two letter " + "country.");
        return false;
    }
    if (len<2) {
        //alert("This address is missing a hostname!");
        return false;
    }
    return true; //address is ok
}


function checkUrl(theUrl){
  if(theUrl.match(/^(http|https)\:\/\/\w+([\.\-]\w+)*\.\w{2,4}(\:\d+)*([\/\.\-\?\&\%\#]\w+)*\/?$/i)){
    return true;
  } else {
    return false;
  }
}

function checkNumber(theNum) {
    if(theNum.match(/\D+/)) {
        return false;
  } else {
    return true;
  }
}

function appsetchk() { // check application settings form
    var lt = trim(document.forms['gettxt'].lefttit.value);
    var lu = trim(document.forms['gettxt'].lefturl.value);
    var rt = trim(document.forms['gettxt'].righttit.value);
    var ru = trim(document.forms['gettxt'].righturl.value);
    var mpl = document.forms['gettxt'].minpwdlen.value ;
    var opw = document.forms['gettxt'].numoldpwds.value ; 
    var pwd = document.forms['gettxt'].pwdwarndays.value ; 
    var awd = document.forms['gettxt'].actwarndays.value ;
    if (lt != '' && (lu == ''|| !checkUrl(lu))) {alert('You must enter a valid URL for ' + lt);}
    else if (lu != '' && lt == '') {alert('You must enter a title for ' + lu);}
    else if (rt != '' && (ru == '' || !checkUrl(ru))) {alert('You must enter a valid URL for ' + rt);}
    else if (ru != '' && rt == '') {alert('You must enter a title for ' + ru);}
    else if (mpl < 4) {alert('Minimum Password length must be at least 4');}
    else if (opw < 1) {alert('You must specify a number of old passwords to remember');}
    else if (pwd < 1) {alert('You must specify a number of days to warn of password expiry');}
    else if (awd < 1) {alert('You must specify a number of days to report on account expiry');}
    else {document.forms['gettxt'].submit();}
}

function pucheck() {//edit administrator/publisher form validation
    var fname = trim(document.forms['getpub'].forename.value);
    var sname = trim(document.forms['getpub'].surname.value);
    var pwdlen = document.forms['getpub'].password.value.length;
    var minpwd = document.forms['getpub'].minpwdlen.value;
    var sysfs = parseInt(document.forms['getpub'].sysfilesize.value);
    var maxfs = parseInt(document.forms['getpub'].maxfilesize.value);
    var phone = trim(document.forms['getpub'].phone.value);
    var pager = trim(document.forms['getpub'].pager.value);
    var email = trim(document.forms['getpub'].email.value);
    var cardid = document.forms['getpub'].cardid.value;
    var nolen = document.forms['getpub'].cardlen.options[0].selected;
    var mkd = document.forms['getpub'].maxkilldays.value ;
    if (sname == '') {alert('You must enter the operators last name !');}
    else if (fname == '') {alert('You must enter the operators first name ! ');}
    else if (pwdlen > 0 && pwdlen < minpwd) {alert('Password is too short, must be at least ' + minpwd + ' characters ! ');}
    else if (email == '') {alert('You must enter an email address !');}
    else if (!mailchk(email)) {var err = 'Invalid email address ' + email;alert(err);}
    else if (phone == '' && pager == '' && cardid == 0) {alert('You must enter a mobile phone number, a pager number or a gridcard id!');}
    else if (!checkNumber(phone)) {alert('Phone number is not valid');}
    else if (!checkNumber(pager)) {alert('Pager number is not valid');}
    else if (cardid > 0 && nolen) {alert('You must specify the number of characters from the card !');}
    else if (mkd < 1) {alert('You must specify a number of days for the maximum published file life');}
    else if (maxfs < 1) {alert('You must specify a maximum allowed file size');}
    else if (maxfs > sysfs) {alert('The maximum allowed file size is ' + sysfs);}
    else {document.forms['getpub'].submit();}
}

function pu2check() {//add administrator/publisher form validation
    var fname = trim(document.forms['getpub'].forename.value);
    var sname = trim(document.forms['getpub'].surname.value);
    var pwdlen = document.forms['getpub'].password.value.length;
    var minpwd = document.forms['getpub'].minpwdlen.value;
    var sysfs = parseInt(document.forms['getpub'].sysfilesize.value);
    var maxfs = parseInt(document.forms['getpub'].maxfilesize.value);
    var phone = trim(document.forms['getpub'].phone.value);
    var pager = trim(document.forms['getpub'].pager.value);
    var email = trim(document.forms['getpub'].email.value);
    var cardid = document.forms['getpub'].cardid.value;
    var nolen = document.forms['getpub'].cardlen.options[0].selected;
    var mkd = document.forms['getpub'].maxkilldays.value ;
    if (sname == '') {alert('You must enter the operators last name !');}
    else if (fname == '') {alert('You must enter the operators first name ! ');}
    else if (pwdlen < minpwd) {alert('Password is too short, must be at least ' + minpwd + ' characters ! ');}
    else if (email == '') {alert('You must enter an email address !');}
    else if (!mailchk(email)) {var err = 'Invalid email address ' + email;alert(err);}
    else if (phone == '' && pager == '' && cardid == 0) {alert('You must enter a mobile phone number, a pager number or a gridcard id!');}
    else if (!checkNumber(phone)) {alert('Phone number is not valid');}
    else if (!checkNumber(pager)) {alert('Pager number is not valid');}
    else if (cardid > 0 && nolen) {alert('You must specify the number of characters from the card !');}
    else if (mkd < 1) {alert('You must specify a number of days for the maximum published file life');}
    else if (maxfs < 1) {alert('You must specify a maximum allowed file size');}
    else if (maxfs > sysfs) {alert('The maximum allowed file size is ' + sysfs);}
    else {document.forms['getpub'].submit();}
}

function rcheck() {//recipient address book form validation
    var fname = trim(document.forms['getpub'].forename.value);
    var sname = trim(document.forms['getpub'].surname.value);
    var email = trim(document.forms['getpub'].email.value);
    var phone = trim(document.forms['getpub'].phone.value);
    var pager = trim(document.forms['getpub'].pager.value);
    var cardid = document.forms['getpub'].cardid.value;
    var nolen = document.forms['getpub'].cardlen.options[0].selected;
    if (sname == '') {alert('You must enter the recipients last name !');}
    else if (fname == '') {alert('You must enter the recipients first name ! !');}
    else if (email == '') {alert('You must enter an email address !');}
    else if (!mailchk(email)) {var err = 'Invalid email address ' + email;alert(err);}
    else if (phone == '' && pager == '') {alert('You must enter a mobile phone number or a pager number !');}
    else if (!checkNumber(phone)) {alert('Phone number is not valid');}
    else if (!checkNumber(pager)) {alert('Pager number is not valid');}
    else if (cardid > 0 && nolen) {alert('You must specify the number of characters from the card !');}
    else {document.forms['getpub'].submit();}
}

function ftcheck() { //filetype validation
    var fd = trim(document.forms['getpub'].descr.value);
    var tp = trim(document.forms['getpub'].type.value);
    if (fd == '') {alert('You must enter a description!');}
    else if (tp.search(/[^a-zA-Z]/) != -1) {alert('File type is invalid!');}
    else {document.forms['getpub'].submit();}
}

function p6check() {// manual recipient form validation
    var fname = trim(document.forms['getpub'].forename.value);
    var sname = trim(document.forms['getpub'].surname.value);
    var oname = trim(document.forms['getpub'].orgname.value);
    var email = trim(document.forms['getpub'].email.value);
    var phone = trim(document.forms['getpub'].phone.value);
    var pager = trim(document.forms['getpub'].pager.value);
    if (sname == '') {alert('You must enter the recipients last name !');}
    else if (fname == '') {alert('You must enter the recipients first name !');}
    else if (email == '') {alert('You must enter an email address !');}
    else if (!mailchk(email)) {var err = 'Invalid email address ' + email;alert(err);}
    else if (oname == '') {alert('You must enter an organisation name !');}
    else if (phone == '' && pager == '') {alert('You must enter a mobile phone number or a pager number !');}
    else if (!checkNumber(phone)) {alert('Phone number is not valid');}
    else if (!checkNumber(pager)) {alert('Pager number is not valid');}
    else {document.forms['getpub'].submit();}
}

function ucheck() { //file upload form validation
    var fname = trim(document.forms['getupl'].usrfile.value.toLowerCase());
    var flen = fname.length;
    var badmsg = '';
    qstart = 4;
    qend = 4 + parseInt(document.forms['getupl'].badnum.value);
    for (var i = qstart; i < qend; i++) {
        var ftype = document.forms['getupl'].elements[i].value.toLowerCase();
        var tlen = ftype.length;
        var istart = flen - tlen;
        var a = fname.indexOf(ftype, istart);
        if (a > -1) {badmsg += 'File type ' + ftype + ' not allowed to be published!\n';}
    }
    if (fname == '') {
        alert('You must select a file to upload !');
    }
    else if (badmsg.length > 0) {
        alert(badmsg);
    }
    else {
        document.getElementById("weight").style.visibility="visible"; 
        document.forms['getupl'].submit();
    }
}

function mcheck () { // message upload check
    var s = trim(document.forms['getupl'].descr.value);
    var b = trim(document.forms['getupl'].body.value);
    if (s == '') {alert('You must enter a title!');}
    else if (b == '') {alert('You must enter an message!');}
    else {document.forms['getupl'].submit();}
}

function f1check() { // normal file upload finish check
    var num = document.forms['getupl'].num.value;
    var disp = 'publish.html?fn=optionsfrm';
    if (num > 0) {
        location.replace(disp);
    }
    else {
        a = window.confirm('Do you want to finish without uploading any files?');
        if (a) location.replace('publish.html?fn=dump');
        }
    }


function f2check() { // end of publishing form validation for one riskform per publication
    var formobj = document.getElementById('getpub');
    var days = formobj.killdays.value;
    var maxdays = formobj.maxkilldays.value;
    var rcps = formobj.numrcp.value;
    var auth = formobj.authoriser.value;
    var errmsg = "";
    if (days == 0 || days > maxdays) {alert('You must enter a valid number of days to live!');}
    else if (auth == 1) {alert('You must select a publisher to authorise this transaction!');}
    else if (rcps == 0) {alert('There are no recipients. Cancel this publication and start again!');}
    else {formobj.submit();}
}

function p4check() { // end of publishing form validation for one riskform per publication
    var formobj = document.getElementById('getpub');
//    qstart = 3 + parseInt(formobj.numrcp.value)  + 3;
    qstart = 3;
    qend = formobj.elements.length;
    var decl = formobj.declare.checked;
    var puballow = true;
    var txterr = false;
    var msg = '';
    var txtmsg = '';
    var anspatn = /^answer\[(\d+)/;
    for (var i = qstart; i < qend; i++) {
        if ((formobj.elements[i].type == 'text' || formobj.elements[i].type == 'textarea') && trim(formobj.elements[i].value) == '') {
            txterr = true;
            var res = formobj.elements[i].name.match(anspatn);
            var anum = parseInt(res[1]) + 1;
            txtmsg = txtmsg + ' Question ' + anum + '.\r\n';
        }
        else if (formobj.elements[i].type == 'radio' && formobj.elements[i].checked == true && formobj.elements[i].value.charAt(0) == 'N') {
            puballow=false
            var res = formobj.elements[i].name.match(anspatn);
            var anum = parseInt(res[1]) + 1;
            msg = msg + ' Question ' + anum + '.\r\n';
        }
        else if (formobj.elements[i].type == 'select-one') {
            for (var j = 0; j < formobj.elements[i].length; j++) {
                if (formobj.elements[i].options[j].selected == true && formobj.elements[i].options[j].value.charAt(0) == 'N'){
                    puballow=false
                    var res = formobj.elements[i].name.match(anspatn);
                    var anum = parseInt(res[1]) + 1;
                    msg = msg + ' Question ' + anum + '.\r\n';
                }
            }
        }
    }
    if (txterr == true ) {alert('You must complete all the risk assessment questions !\r\n' + txtmsg);}    
    else if (puballow != true ) {alert('Some of your answers indicate that publication is forbidden !\r\n' + msg);}    
    else if (decl != true ) {alert('You must complete the declaration !');}    
    else {formobj.submit();}
}

function f4check() { // end of publishing form validation for one riskform per file
    var formobj = document.getElementById('getpub');
    var puballow = true;
    var txterr = false;
    var msg = '';
    var txtmsg = '';
    var anspatn = /^f(\d+)answer(\d+)/;
//    qstart = 3 + parseInt(formobj.numrcp.value)  + 2;
    qstart = 2;
    qend = formobj.elements.length ;
    for (var i = qstart; i < qend; i++) {
        if ((formobj.elements[i].type == 'text' || formobj.elements[i].type == 'textarea') && trim(formobj.elements[i].value) == '') {
            txterr = true;
            var res = formobj.elements[i].name.match(anspatn);
            var anum = parseInt(res[2]) + 1;
            var flnm = eval('formobj.' + 'fname' + res[1] + '.value');
            txtmsg = txtmsg + 'File ' + flnm + ' Question ' + anum + '.\r\n';
        }
        else if (formobj.elements[i].type == 'radio' && formobj.elements[i].checked == true && formobj.elements[i].value.charAt(0) == 'N') {
            puballow=false;
            var res = formobj.elements[i].name.match(anspatn);
            var anum = parseInt(res[2]) + 1;
            var flnm = eval('formobj.' + 'fname' + res[1] + '.value');
            msg = msg + 'File ' + flnm + ' Question ' + anum + '.\r\n';
        }
        else if (formobj.elements[i].type == 'select-one') {
            for (var j = 0; j < formobj.elements[i].length; j++) {
                if (formobj.elements[i].options[j].selected == true && formobj.elements[i].options[j].value.charAt(0) == 'N'){
                    puballow=false;
                    var res = formobj.elements[i].name.match(anspatn);
                    var anum = parseInt(res[2]) + 1;
                    var flnm = eval('formobj.' + 'fname' + res[1] + '.value');
                    msg = msg + 'File ' + flnm + ' Question ' + anum + '.\r\n';
                }
            }
        }
    }
    var decl = formobj.declare.checked;
    if (txterr == true ) {alert('You have not answered all the risk assessment questions !\r\n' + txtmsg);}
    else if (puballow != true ) {alert('Some of your answers indicate that publication is forbidden !\r\n' + msg);}
    else if (decl != true ) {alert('You must complete the declaration !');}
    else {formobj.submit();}
}

function test2() { // used for testing stuff NOT in production
    var formobj = document.getElementById('getpub');
    qstart = 3 + parseInt(formobj.numrcp.value)  + 2;
    qend = formobj.elements.length;
    var names = '';
    for (var i = qstart; i < qend; i++) {
        var ch = 'n/a';
        if (formobj.elements[i].type == 'radio' && formobj.elements[i].checked == true) {ch = 'checked';}
        names = names + i + ' = ' + formobj.elements[i].name + ' = ' + formobj.elements[i].type + ' = ' + formobj.elements[i].value + ' Checked = ' + ch + '\r\n';
    }
    alert(names);
}
    
function riskchk() { // risk assessment form question validation
    var max = parseInt(document.forms['gettxt'].maxlen.value);
    var qt = trim(document.forms['gettxt'].fieldlabel.value);
    var qo = trim(document.forms['gettxt'].dispord.value);
    var al = trim(document.forms['gettxt'].datalen.value);
    var selc = document.forms['gettxt'].pick.options[1].selected;
    var ans = document.getElementsByName('ptext[]');
    if (qt == '') {alert('You must enter a question !');}
    else if (qt.length > max) {alert('Question is too long');}
    else if (!checkNumber(qo) || qo == 0) {alert('You must enter a number for Order');}
    else if (!checkNumber(al) || al == 0) {alert('You must enter a number for Answer Length');}
    else if (parseInt(al) > max) {alert('Answer length is too long');}
    else if (selc && al > 60) {alert('Answer length is too long for a select list');}
    else if (ans.length > 0) { 
        var amsg = '';
        for (i = 0; i < ans.length; i++) {
            j = i+1;
            if (ans[i].value.length > al) {amsg = amsg + 'Answer ' + j + ' is too long\r\n';}
        }
        if (amsg.length > 0) {alert(amsg);}
        else {document.forms['gettxt'].submit();}
        }
    else {document.forms['gettxt'].submit();}
}

function fondle(inst) {
    document.forms['getupl'].manhandle.value = inst
}