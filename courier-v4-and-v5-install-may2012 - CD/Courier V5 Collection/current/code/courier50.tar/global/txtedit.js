/*  ========================================================================================
Application: Courier v5.0
Filename: global/txtedit.js
Called by: notext.html
Description/Notes: Letter template editor functions.
Update History:
25/03/11 DSK - Courier v4.0 release
16/02/11 MD  - Added checks for SMS messages
15/01/10 DSK - Released
============================================================ */
function chkotpsms() {
    var bdy1 = document.forms['gettxt'].first.value;
    var bdy2 = document.forms['gettxt'].last.value;
    var len1 = document.forms['gettxt'].first.value.length;
    var len2 = document.forms['gettxt'].last.value.length;
    var idextra1 = 0;
    var orgextra1 = 0;
    var idextra2 = 0;
    var orgextra2 = 0;
    var otp = /%OTP%/;
    var ref = /%TRANSID%/;
    var org = /%SEND-ORG%/;
    if (ref.test(bdy1)) {idextra1 = 5;}
    if (org.test(bdy1)) {orgextra1 = 50;}
    if (ref.test(bdy2)) {idextra2 = 5;}
    if (org.test(bdy2)) {orgextra2 = 50;}
    var maxlen1 = 156 - idextra1 - orgextra1;
    var maxlen2 = 156 - idextra2 - orgextra2;

    if (len1 > maxlen1) {alert('Warning: Recipient SMS message can only have 160 characters, including the actual text represented by parameters from the pick list.')}
    if (len2 > maxlen2) {alert('Warning: Operator SMS message can only have 160 characters, including the actual text represented by parameters from the pick list.')}
    if (!otp.test(bdy1)) {alert('You must include password in recipient message');}
    else if (!otp.test(bdy2)) {alert('You must include password in publisher message');}
    else {document.forms['gettxt'].submit();}
}

function chknotsms() {
    var bdy1 = document.forms['gettxt'].first.value;
    var len1 = document.forms['gettxt'].first.value.length;
    var len2 = document.forms['gettxt'].last.value.length;
    var idextra = 0;
    var orgextra = 0;
    var ref = /%TRANSID%/;
    var org = /%SEND-ORG%/;
    if (ref.test(bdy1)) {idextra = 5;}
    if (org.test(bdy1)) {orgextra = 50;}
    var maxlen = 160 - idextra - orgextra;
    if (len1 > maxlen || len2 > maxlen) {alert('Warning: SMS messages can only have 160 characters, including the actual text represented by parameters from the pick list.');}
    document.forms['gettxt'].submit();
}

function chknotify() {
    var bdy1 = document.forms['gettxt'].first.value;
    var bdy2 = document.forms['gettxt'].last.value;
    var usr = /%USER%/;
    var pwd = /%PASS%/;
    var msg = /%MESSAGE%/;
    if (usr.test(bdy1) && pwd.test(bdy1) && msg.test(bdy1) && msg.test(bdy2)) {document.forms['gettxt'].submit();}
    else {alert('You must include username and password for recipient \nand the publishers message for both');}
}

function chkauth() {
    var bdy1 = document.forms['gettxt'].first.value;
    var bdy2 = document.forms['gettxt'].last.value;
    var usr = /%AUTHORISER%/;
    var msg = /%REFUSE%/;
    if (msg.test(bdy2) && usr.test(bdy1) && usr.test(bdy2)) {document.forms['gettxt'].submit();}
    else {alert('You must include the reason when denying authorisation \nand the authoriser name for both');}
}

function insParm(edt, parm) {
    var e = document.getElementById(edt);
    var text = parm;
    return (
        ('selectionStart' in e && function() {e.value = e.value.substr(0, e.selectionStart) + text + e.value.substr(e.selectionEnd, e.value.length);return this;}) ||
        (document.selection && function() {e.focus();document.selection.createRange().text = text;return this;}) ||
        function() {e.value += text;return this;}
        )();
}

function formatText (edt,tag) {
    var txtArea = document.getElementById(edt);
    var start = txtArea.selectionStart;
    var end   = txtArea.selectionEnd;
    var pre = txtArea.value.substring(0, start);
    var post = txtArea.value.substring(end, txtArea.value.length);
    var selTxt = txtArea.value.substring(start, end);
    if (selTxt != "") {
        var newTxt = "<" + tag + ">" + selTxt + "</" + tag + "> ";
        txtArea.value = pre +  newTxt + post;
        txtArea.focus(); 
        txtArea.setSelectionRange(start + newTxt.length, start + newTxt.length);
        var evt = document.createEvent("KeyboardEvent");
        evt.initKeyEvent("keypress", true, true, null, false, false, false, false, 8, 8);
        txtArea.dispatchEvent(evt);
        txtArea.setSelectionRange(start, start + newTxt.length -1);
    }
}