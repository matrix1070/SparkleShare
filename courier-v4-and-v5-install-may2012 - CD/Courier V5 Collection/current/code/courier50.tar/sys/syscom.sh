#!/bin/bash

logfile="/root/log.log"
/bin/echo "LOG: $(/bin/date)" > $logfile
/bin/echo >> $logfile
while test 1; do            ###Forever
   /bin/echo >> $logfile
   /bin/echo "Begin Cycle: $(/bin/date) **********" >> $logfile
   /bin/echo "CMD" | /usr/bin/tee -a $logfile
   read cmd p1 p2 p3

   /bin/echo ":$cmd $p1 $p2 $p3" >> $logfile
   case "$cmd" in
          (CKS)     xec="/usr/local/bin/cks.php $p1 $p2";;
          (LGV)     xec="/usr/local/bin/lgv.php $p1 $p2";; 
          (MLQ)     xec="/usr/local/bin/mlq.php $p1 $p2";;
          (SSL)     xec="/usr/local/bin/ssl.php $p1 $p2";;
          (Q*)      xec="exit"; break;;
          (*)       xec="/bin/echo Unknown; break";;
   esac
   (( $xec 2>&1 1>&3 | tee /root/error) 3>&1 1>&2 ) >> $logfile 2>&1

   /bin/echo "OK"
   /bin/echo "OK $xec" >> $logfile
done
/bin/echo  | /usr/bin/tee -a $logfile
/bin/echo "BYE" | /usr/bin/tee -a $logfile
