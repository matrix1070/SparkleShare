<?php
/*  ========================================================================================
Application: Courier v5.0
Filename: cssmain.php
Called by: All publisher and recipient pages
Description/Notes: Main style sheet for publishers and recipients
Update History:
06/04/12 DSK - First release
========================================================================================= */
require "./global/main.inc";

/* --------- Header / Banner #header, #banner -----------*/
$hdbg   = "#fff";
$hdfg   = "#0089d8";

/* --------- Main body #icont -----------*/
$contbg = "#ffd";

/* --------- Sub-menu / toolbar #submenu, #toolbar-----------*/
$tbbg   = "#ffd";
$tbbgh  = "#ffd";
$tbfg   = "blue";
$tbfgh  = "darkblue";
$tbbdr  = "#000";

/* --------- Footer #footer -----------*/
$ftbg       = "#fff";
$ftfg       = "#000";


// get user defined style settings from style table
mysql_select_db($aDB, $CNX);
$r  =  mysql_query("SELECT * FROM csssettings WHERE 1"); //WHERE sheet='main'
if($r):
    while($css = mysql_fetch_array($r)) {${$css['setting']} = $css['value'];}
endif;
/*/If we have some and the reset colours $_GET{'reset'] var is not set we set up the new values
else we use the predefined defaults.
*/
header('Content-type: text/css');

echo <<<EOT
@import url("./global/reset.css");

/* Main styles for whole site */
html {background:#efeccc;}
body {font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#000;background:#fff;width:1173px;margin:0 auto !important;}

#hlpBox{position:absolute;top:68px;left:31px;height:auto;width:460px;background:#dfd;padding:0;text-align:left;border:2px outset #444;display:none;z-index:999}
#helpicon {position:absolute;top:12px;right:20px;;margin:}
#helptitle {font-size:125%;font-weight:bold;width:100%;margin:0;text-align:center;background:#666;color:#ddd;padding:4px 0;}
#helpbody {width:96%;margin:10px auto 0;}
.help {font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#000;}

#icont {display:block;clear:both;width:100%;margin:0;min-height:400px;padding-bottom:16px;background:$contbg;position:relative;}
#icont p {font-size:14px;line-height:1.4;}
.topbdr {border-top:2px solid #000;}

img {vertical-align:middle;border:none;}
button {color:#000; background:#eee; border:1px solid #000; padding:3px 10px; font-size:14px; font-weight:normal; white-space:nowrap; margin: 0 1em;border-radius:5px;}
button.notyet {color:#ccc;background:#fff; border: 1px solid #ccc;}
.txtc {text-align:center;}
.nowrap {white-space:nowrap}
.btnbox {width: 60%; margin: 15px auto; text-align:center;}
a.tblhd {text-decoration:underline;text-align:center;}

#header {display:block;width:100%;height:110px;margin:0;position:relative;background:$hdbg;}
#sitelogo {width:256px; float:left;}
#banner {float:left;font-size:24px;font-weight:bold;color:$hdfg;margin:25px;}

#owner {position:absolute;height:22px;overflow:hidden;width:220px;top:3px;right:10px;background:url(./img/cog.png) 200px 0px no-repeat;line-height:1.8;border-radius:8px;padding:5px 5px;t}
#owner:hover {position:absolute;display:block;height:auto;background:#ddd;z-index:99}
#owner .uname {font-weight:normal;}

#topmenu {font-family:Tahoma;position:absolute;width:1173px;margin:0;top:76px;text-transform:uppercase;border-bottom:2px solid #000;}
#topmenu ul {float:right;margin:0;list-style:none;position:relative;top:3px}
#topmenu li {float:right;margin:0 2px;border-top:2px solid #000; border-left:2px solid #000;border-right:2px solid #000;border-radius:4px;background:#fff;}
#topmenu a {display:block;padding:5px 15px 4px 6px;text-decoration:none;font-weight:700;font-size:14px;color:#333;}
#topmenu a:hover {color:#aaa !important;}
#topmenu a.current:hover {color:#888 !important;}
#topmenu a.current {color:#888;border-bottom:3px solid $contbg;background:$contbg;}
#topmenu span.sup {color:red;}

/* Toolbar menu */
#submenu {display:block;min-height:20px;margin:0;font-family:Tahoma;position:relative;top:1px;}
#submenu a {float:left;margin:0;padding:3px 8px;border:1px solid $tbbdr;text-decoration:none;color:$tbfg;font-weight:bold;background:$tbbg;}
#submenu ul {float:left;margin:0;padding:0;list-style:none;}
#submenu li {float:left;margin:0;}
#submenu a:hover {color:$tbfgh;text-decoration:underline;cursor:pointer;background:$tbbgh;}

#subcont {display:block;clear:both;width:96%;margin:40px auto 0;padding:8px;border:1px solid #ffd;top:146px;background:#ddd;border-radius:18px;}
#subcont h2 {font-weight:bold;font-size:18px !important;margin:8px 0 0;}
#subcont p {font-size:12px !important;}

#galert {display:block;clear:both;width:550px;min-height:20px;margin:0 auto;border-radius:14px;background:#ff0;padding:8px;text-align:center;position:relative;top:20px;}
#galert .ph {font-weight:bold;color:red;font-size:18px;padding:0;margin:0;}

#footer {display:block;clear:both;width:100%;height:100px;margin:0;border-top:1px solid #000;overflow:hidden;background:$ftbg;}
#footer a {font-size:14px;text-decoration:none;font-weight:bold;color:$ftfg;}
#lftlnk {display:block;width:345px;float:left;margin:35px 10px 0 30px;text-align:left;}
#blogo {width:256px;float:right;}
#rtlnk {display:block;width:345px;float:left;margin:35px 10px 0 35px;text-align:right;}

#login,#welcome {display:block;position:relative;top:20px;width:550px;min-height:260px;margin:0 auto;background:#cfe2f3;padding:20px;border-radius:14px}
#login input{width:22em;}
#login label{text-align:right;font-size:120%;font-weight:bold;line-height:1.3;margin-bottom:14px;width:100px;padding-right:10px;float:left;color:#666; }
#login label.long {width: 200px;}
#login p{margin:10px auto;font-weight:normal !important;font-size:13px;border:1px solid #000;background:#fff;padding:5px;}
.inform {}
.remind {font-size:9px;text-align:center;}

#welcome {}
#welcome h2 {font-size:16px;font-weight:bold;text-align:left;line-height:1.8;margin:0;color:#21296f;}
#welcome p {font-weight:normal !important;line-height:1.8;margin:0;padding:6px 0;}

#gridcard {float:left;height:35px;padding:6px 0 0;width:540px;margin-top:30px}
#gridcard select{margin:0 5px 0 0; padding:0;float:left;width:auto;}
#gridcard label{width:2em; margin:0 2px 0 0;text-align:right;font-size:18px;font-weight:bold;line-height:1.4;padding-right:3px;}

#pubmenu {float:left;display:block;width:50%;margin:40px 0;border-right:2px solid #000;}
#pubmenu button {color:#333;background:#eee;border:1px solid #000;width:8em;font-size:16px;font-weight:normal;padding:10px 0;margin:10px 20px;float:left;}
#pubmenu button.notick {background:#eee;}
#pubmenu button.notick:hover{color:#000;text-decoration:underline;cursor:pointer;}
#pubmenu button.tick {background:#b7d7a9;}
#pubmenu button.tick:hover{color:#000;text-decoration:underline;cursor:pointer;}
#pubmenu button.notyet {color:#ccc;background:#fff;border:1px solid #ccc;}
#pubmenu img {visibility:hidden;display:inline-block;position:relative;left:-60px;top:-10px}
#pubmenu img.rtick,#pubmenu img.ftick,#pubmenu img.otick {visibility:visible;}
.butinf {display:inline-block; margin: 30px 20px;}

#pubtext {float:left;display:block;width:350px;margin:40px 0 0 70px;}
#pubtext p {text-align:justify;font-weight:bold;font-size:120%;}
#pubtext h1 {text-decoration:underline;text-align:center;}
#pubtext button {display:inline-block;float:left;color:#333;background:#eee;border:1px solid #000;width:160px;font-size:16px;font-weight:normal;padding:20px 0;margin:0 6px;}
#pubtext button.notick{color:#ccc;background:#fff; border:1px solid #ccc;}
#pubtext button.notick:hover{color:#ccc;}
#pubtext button.alltick:hover{color:#000;text-decoration:underline;cursor:pointer;}
#pubtext button.canc {color:red;border:1px solid #ccc;}

#publist{display:block;background:#fff;margin:0 auto;width:95%;padding:8px 0;}
#publist p{clear:both;text-align:center;font-weight:bold;color:#000;font-size:14px}
#publist table{width:101%;margin:-3px 0 0 -4px;border-collapse:collapse;}
#publist th{color:#000;font-size:13px;font-weight:bold;text-align:center;padding:0;border-right:1px solid #bbb;height:35px}
#publist td{color:#000;font-size:13px;font-weight:normal;border-bottom:1px solid silver;border-right:1px solid #bbb;line-height:2.4;padding-left:4px}
#publist td.nodnld {font-weight:bold;}
#publist td:last-child, #publist th:last-child {border-right:none;}
#publist tr:last-child td{border-bottom:none;}
#publist .fnotice{width:80%;padding:5px;background:#eee;border:1px solid #bbb;margin:18px auto;font-weight:normal}
#publist .dnlife{font-weight:bold;}
#publist .hd{font-size:16px;}

.tblcnt {display:block;clear:both;padding:5px;margin:0 15px;}
.tblcnt table {border:3px solid #bbb;width:100%}
.tblcnt p {font-size:13px;font-weight:normal;margin:0;}
.tblcnt th {background:#bbb;text-align:left;padding:3px;}
.tblcnt th.reorder {text-decoration:underline; text-align:left;}
.tblcnt tr td {line-height:1.3 !important;padding:3px;}
.tblcnt tr.nodnld td {font-weight:bold !important;}
.clkbl:hover {background:#81c8f1;cursor:pointer;}
.alarm {background:#fff060;}
.grplst table {width:auto;}

.addsrch {clear:both;float:left;width:100%;margin:10px 0;text-align:center;}
.addsrch span {font-weight:normal;margin-left:100px;}
.addsrch form {display:inline}
.addsrch label {padding-right:4px;font-weight:bold;}
.addsrch textarea {width:40em;}
.addsrch button {font-size:12px; width:10em; margin: 0px 10px;}

.trow10 {background:#ffffff}
.trow11 {background:#f0f0f0;}

#pblshd {display:block;width:520px;height:auto;background:#ddd;margin:20px auto;padding:10px 12px;border-radius:18px}
#pblshd p {}
#pblshd p label {display:inline-block;text-align:right;font-size:13px;font-weight:bold;width:10em;padding-right:.5em;}
#pblshd p span {display:inline-block;text-align:left;width:24em;padding:0 1em;line-height:1.4;font-size:13px;background:#fff}
#pblshd textarea {width:510px;}

/* -----------------------------------  Print  Styles -------------------------------------- */
body.list {font-family:Arial,Helvetica,sans-serif; background: #fff;background:#fff;color:#000;width:100%;}
#prnfrm {background:#fff;font-size:80%;line-height:120%;margin-left:5%;padding-left:1em;width:90%;}
#prnrm table {width:100%;margin:auto;}
#prnfrm tr.file {background:#eef;}
#prnfrm td.file {border-top: 1px solid black;}
#prnfrm th {background:#21296A;color:#fff;font-size:120%;font-weight:bold;text-align:left;line-height:130%;padding:3px}
#prnfrm td {color:#000;font-size:100%;font-weight:normal;}

/* ---------------------------------------------- form styles  ---------------------------------------------- */

#sfrm {clear:both;width:80%;margin:20px auto;border-radius:16px;border:1px solid #999;padding:10px}
#sfrm label {text-align:right;font-size:13px;font-weight:bold;display:inline-block;margin-bottom:6px;width:220px;padding-right:10px;line-height:1.6;color:#666}
#sfrm input {width:18em}

#radopts {display:inline;line-height:2.5;}
#radopts input {margin:10px 0px;}
#radopts label {font-weight:normal;text-align:right;font-size:13px;margin:10px 10px 0 ;width:8em;line-height:2.5;}

.uplode-l {float:left; width:45%; margin:5px; padding:10px}
.uplode-l label {text-align:left;font-size:13px;font-weight:bold;display:inline-block;float:left;width:100%;margin:0.6em 0;line-height:1.6;color:#666}
.uplode-l input.ftp {display:block; width:auto;margin-bottom:30px}
.uplode-r {float:right; width:45%; margin:5px; padding:10px}
.uplode-r label {text-align:left;font-size:13px;font-weight:bold;display:inline-block;float:left;width:100%;margin:0.6em 0;line-height:1.6;color:#666}
.uplode-r textarea {display:block;width:400px;}
.uplode-r button {float:right;margin:10px 150px 40px 0;}

#weight {width:60%;margin:0 auto;font-weight:bold;font-size:18px;text-align:center;color:#e78514;visibility:hidden;}
#weight img {margin:0 .5em 1.2em 1em;}

.cfrm {clear:both;width:80%;margin:20px auto;background:#ddd;border:1px solid #999;padding:10px;border-radius:18px;}
.cfrm label {text-align:right;font-size:13px;font-weight:bold;display:inline-block;float:left;margin-bottom:6px;width:15em;padding-right:1em;line-height:1.6;color:#000}
.cfrm input {width:18em}

/* --------------------------------------- Risk Assessment Form ------------------------------------------ */

#raform {display:block;padding:8px;text-align:left;font-size:10px;}
.uplode {clear:both;width:90%;margin:20px auto;background:#fff;padding:10px}

.rq {display:block;clear:both;width:99%;color:#000;font-weight:bold;text-align:justify;padding:8px 4px;border-top:2px solid #000;margin-top:8px;line-height:1.2;}
#raform textarea, input.raft {width:800px;}
.rarb {margin:0 0 0 3px;padding:3px 3px;font-weight:normal;font-size:120%;background:#fff;}
.fq {display:block;font-weight:normal;font-size:90%;background:#fff;margin:2px auto;color:#000;width:85%;padding:0 8px;text-decoration:none;}
.radecl  {display:block;background:#efefef;padding:8px;text-align:left;line-height:1.2;border-top:2px solid #000;font-size:5px !important;font-weight:normal !important;}
#dclrr {display:inline-block;width:20em;font-weight:bold;}
#accordion {font-size:140%;}
EOT;
?>