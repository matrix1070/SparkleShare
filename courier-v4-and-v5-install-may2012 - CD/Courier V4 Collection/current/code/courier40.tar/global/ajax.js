/*  ==================================================================================
Filename: [Courier v4.2] /global/ajax.js
Called by: various
Description/Notes:  Javascript routines for ajax version of typedown search, 
                    submitting forms by POST and using GET
Update History:
06/10/11 DSK - Courier v4.2 release - bug fixes
25/03/11 DSK - Courier v4.0 release
16/05/09  MD - Added function getstuff
14/07/08  MD - Released
====================================================================================== */
function disableEnterKey() {
    if (window.event.keyCode == 13) {
        window.event.keyCode = 0;
    }
}

function srchfld(){
    document.f1.srchstr.value='';
    document.f1.srchstr.focus();
}


function getxmlhttp() {
    var xmlhttp = false;
    try {
        xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
        msg = 'You are using newer MS IE';
    }
    catch (e) {
        try {
            xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
            msg = 'You are using older MS IE';
        }
        catch (E) {
            xmlhttp = new XMLHttpRequest();
            msg = 'You are not using MS IE';
        }
    }
    return xmlhttp;
}	

function processit(SvrPg, target, GorP, str) {
    xmlhttp = getxmlhttp()
    if (GorP == 'GET') {
        var url = SvrPg+"&seq="+Math.random();
        xmlhttp.open('GET', url);
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                target.innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.send(null);
    }
    else {
        xmlhttp.open('POST', SvrPg, true);
        xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                target.innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.send(str);
    }
}

function getformdata(formobj) {
// normally validation would be good
    var str = '';
    for (var i = 0; i < formobj.elements.length; i++) {
        if (formobj.elements[i].type == 'radio' || formobj.elements[i].type == 'checkbox') {
            if (formobj.elements[i].checked == true) {
                str += formobj.elements[i].name + '=' + escape(formobj.elements[i].value) + '&';
            }
        }
        else if (formobj.elements[i].type == 'select-one' || formobj.elements[i].type == 'select-multiple') {
            for (var j = 0; j < formobj.elements[i].length; j++) {
                if (formobj.elements[i].options[j].selected == true) {
                    str += formobj.elements[i].name + '=' + escape(formobj.elements[i].options[j].value) + '&';
                }
            }
        }
        else {
            str += formobj.elements[i].name + '=' + escape(formobj.elements[i].value) + '&';
        }
    }
    return str;
}

// called from input field in form f1 by onkeyup="submitform('f1','getdata.php', 'dest')
// getdata is a php script and dest is the id of the target div in the web page
function submitform(formid, SvrPg, targetid) {
    var formobj = document.getElementById(formid);
    var str = getformdata(formobj);
    target = document.getElementById(targetid);
    processit(SvrPg, target, 'POST', str);
}

// called from timer in page pubdash.html getstuff('url_inc_parameters', 'dest')
// url_inc_parameters is the full url and parameters for a php script and dest is the id of the target div in the web page
function getstuff(SvrPg, targetid) {
    var str = '';
    target = document.getElementById(targetid);
    processit(SvrPg, target, 'GET', str);
}