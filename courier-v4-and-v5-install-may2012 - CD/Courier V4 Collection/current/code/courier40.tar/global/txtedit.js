/*  ========================================================
Filename: [Courier v4.2] global/txtedit.js
Called by: notext.html
Notes: Letter template editor functions.
Update history:
25/03/11 DSK - Courier v4.0 release
16/02/11 MD  - Added checks for SMS messages
15/01/10 DSK - Released
============================================================ */
function chkotpsms() {
    var bdy1 = document.forms['gettxt'].first.value;
    var bdy2 = document.forms['gettxt'].last.value;
    var len1 = document.forms['gettxt'].first.value.length;
    var len2 = document.forms['gettxt'].last.value.length;
    var idextra1 = 0;
    var orgextra1 = 0;
    var idextra2 = 0;
    var orgextra2 = 0;
    var otp = /%OTP%/;
    var ref = /%TRANSID%/;
    var org = /%SEND-ORG%/;
    if (ref.test(bdy1)) {idextra1 = 5;}
    if (org.test(bdy1)) {orgextra1 = 50;}
    if (ref.test(bdy2)) {idextra2 = 5;}
    if (org.test(bdy2)) {orgextra2 = 50;}
    var maxlen1 = 156 - idextra1 - orgextra1;
    var maxlen2 = 156 - idextra2 - orgextra2;

    if (len1 > maxlen1) {alert('Warning: Recipient SMS message can only have 160 characters, including the actual text represented by parameters from the pick list.')}
    if (len2 > maxlen2) {alert('Warning: Publisher SMS message can only have 160 characters, including the actual text represented by parameters from the pick list.')}
    if (!otp.test(bdy1)) {alert('You must include password in recipient message');}
    else if (!otp.test(bdy2)) {alert('You must include password in publisher message');}
    else {document.forms['gettxt'].submit();}
}

function chknotsms() {
    var bdy1 = document.forms['gettxt'].first.value;
    var len1 = document.forms['gettxt'].first.value.length;
    var idextra = 0;
    var orgextra = 0;
    var ref = /%TRANSID%/;
    var org = /%SEND-ORG%/;
    if (ref.test(bdy1)) {idextra = 5;}
    if (org.test(bdy1)) {orgextra = 50;}
    var maxlen = 160 - idextra - orgextra;
    if (len1 > maxlen) {alert('Warning: SMS messages can only have 160 characters, including the actual text represented by parameters from the pick list.');}
    document.forms['gettxt'].submit();
}

function chknotify() {
    var bdy = document.forms['gettxt'].first.value;
    var usr = /%USER%/;
    var pwd = /%PASS%/;
    if (usr.test(bdy) && pwd.test(bdy)) {document.forms['gettxt'].submit();}
    else {alert('You must include username and password');}
}

function insParm(edt, parm) {
    var e = document.getElementById(edt);
    var text = parm;
    return (
        ('selectionStart' in e && function() {e.value = e.value.substr(0, e.selectionStart) + text + e.value.substr(e.selectionEnd, e.value.length);return this;}) ||
        (document.selection && function() {e.focus();document.selection.createRange().text = text;return this;}) ||
        function() {e.value += text;return this;}
        )();
}
    